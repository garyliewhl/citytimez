<?php
	$conn = new mysqli('localhost', 'root', '', 'CityTimez');
	if(!$conn){
		die("Fatal Error: Connection Error!");
	}

?>
