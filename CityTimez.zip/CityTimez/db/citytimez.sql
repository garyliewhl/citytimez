-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2019 at 08:42 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citytimez`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `email`, `message`) VALUES
(26, 'gary@ct.com', 'very trustable company, would recommend my friends and family.'),
(27, '', ''),
(28, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerid` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `mi` varchar(1) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(50) NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerid`, `firstname`, `mi`, `lastname`, `address`, `country`, `zipcode`, `mobile`, `telephone`, `email`, `password`) VALUES
(2, 'Gary', 'H', 'Liew', 'abcd', 'Selangor', '4750', '0123456789', '', 'gary@ct.com', '111111'),
(3, 'Jason', 'J', 'Tan', 'abcd', 'Selangor', '4750', '0124567893', '', 'jason@ct.com', '222222'),
(4, 'Jun', 'Y', 'Siau', 'abcd', 'Selangor', '4750', '0129874563', '', 'siaujy@ct.com', '333333');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_size` varchar(50) NOT NULL,
  `product_image` varchar(500) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_price`, `product_size`, `product_image`, `brand`, `category`) VALUES
(26, 'Fossil Q Watch (Gen 4)', '2300', '45', 'FTW4012.jpg', 'Fossil', 'smart'),
(36, 'Michael Kors Access Bluetooth Smartwatch', '2000', '38', 'MKT5056.jpg', 'Michael Kors', 'smart'),
(253, 'Braun Buffel Men Watch BB1010', '3500', '44', 'braun-buffel-0366-3445061-1.jpg', 'Braun Buffel ', 'feature'),
(288, 'REC 901-01', '7072', '44', 'rec-porsche-911-901_1b__75498.1507903225.jpg', 'REC', 'automatic'),
(6196, 'CLASSIC SHEFFIELD + CORNWALL STRAP', '1070', '40', 'dw00500008.jpg', 'Daniel Wellington', 'feature'),
(6661, 'Unisex Gucci Gucci Dive Watch', '5600', '45', 'ya136216_001-1495551844-8427.jpg', 'Gucci', 'feature'),
(6976, 'Cerruti 1881 Veliero Chronograph Leather ', '1300', '46', 'cerruti-1881-0537-5819671-1.jpg', 'Cerruti 1881 ', 'feature'),
(9153, 'Emporio Armani Luigi Silver Watch', '1900', '43', '266133-2254-331662-2-detail.jpg', 'Armani', 'feature'),
(39112, 'OMEGA Speedmaster MOONWATCH PROFESSIONAL CHRONOGRA', '23200', '42', 'omega-speedmaster-moonwatch-31130423001006-list.jpg', 'OMEGA', 'automatic'),
(80550, 'Michael Kors Access Runway', '2000', '42', 'MKT5044_main.jpg', 'Michael Kors', 'smart'),
(91088, 'Orient Star Mechanical Moon', '5000', '41', 'RK-AM0002L.jpg', 'Orient', 'feature'),
(168442, 'Casio G-Shock Full Metal Bluetooth Watch', '2300', '49', 'GMW-B5000GD-9ER.jpg', 'Casio ', 'digital'),
(254125, 'REC P-51-03', '6238', '44', 'REC-p51-03-1__72977.1490032008.jpg', 'REC', 'automatic'),
(844125, 'Adidas Originals Watch', '500', '42', 'Z16-3199-view1.jpg', 'Adidas Originals', 'digital'),
(6610738, 'Ladies Hugo Boss Diamonds', '2600', '33', '1502524_LRG_rgb_Web.jpg', 'Hugo Boss', 'automatic');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `product_id`, `qty`) VALUES
(40, 80550, 25),
(51, 6976, 23),
(50, 91088, 31),
(49, 253, 28),
(48, 9153, 16),
(47, 6661, 18),
(46, 6196, 23),
(45, 288, 10),
(44, 254125, 10),
(43, 844125, 10),
(42, 26, 10),
(41, 168442, 30),
(39, 36, 25),
(38, 424, 25),
(37, 21642, 25),
(36, 6610738, 40),
(35, 248989, 20),
(34, 39112, 29);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `order_stat` varchar(100) NOT NULL,
  `order_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transaction_id`, `customerid`, `amount`, `order_stat`, `order_date`) VALUES
(0, 2, 23200, 'Confirmed', 'Sep 11, 2019'),
(8985, 2, 10572, 'Confirmed', 'Sep 11, 2019');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_detail`
--

CREATE TABLE `transaction_detail` (
  `transacton_detail_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `order_qty` int(11) NOT NULL,
  `transaction_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction_detail`
--

INSERT INTO `transaction_detail` (`transacton_detail_id`, `product_id`, `order_qty`, `transaction_id`) VALUES
(30, 39112, 1, 0),
(29, 253, 1, 8985),
(28, 288, 1, 8985);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `transaction_detail`
--
ALTER TABLE `transaction_detail`
  ADD PRIMARY KEY (`transacton_detail_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `transaction_detail`
--
ALTER TABLE `transaction_detail`
  MODIFY `transacton_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
